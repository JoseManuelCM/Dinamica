import java.awt.*;
import java.util.ArrayList;
import javax.swing.JFrame;
public class Monitor extends JFrame{
    
    private Dimension dim;
    public static ArrayList<Proceso> procesos = new ArrayList<Proceso>();
    public static ArrayList<Particion> memoria = new ArrayList<Particion>();
    public static ArrayList<Integer> borrar = new ArrayList<Integer>();
    public static Memoria display = new Memoria(100);
    Monitor(){
        super("Gestión de memora Variable");
        dim = new Dimension(800,800);
        this.setSize(dim);
        this.setBackground(Color.BLACK);
        this.setLayout(null);
        this.add(display);
        this.setVisible(true);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        memoria.add(new Particion(0,100,null));
        rellenar();
        prueba();
    }
    
    public static void prueba(){
        gestionar();
        mostrar();
        borrar();
        System.out.println("procesows pendientes: "+procesos.size());
    }
     
    public static void rellenar()
    {
        procesos.add(new Proceso(20,100,"S.O"));
        procesos.add(new Proceso(20,2, "0"));
        procesos.add(new Proceso(30,3,"1"));
        procesos.add(new Proceso(40,4,"2"));
        procesos.add(new Proceso(20,5,"3"));
        procesos.add(new Proceso(50,6,"4"));
    }
    public static void gestionar(){
        int particion;   
        int size = procesos.size();
        Proceso p;
        for (int i = 0; i<size; ++i)
        {
            p = procesos.get(i);
            if((particion = asignar(p)) != -1) 
            {
                particionar(particion, p);
                borrar.add(0, i);
            }
        }
    }
    
    //encuentra una particion lo suficientemente grande para el proceso
    public static int asignar(Proceso p){
        int tam = memoria.size();
        for (int i=0; i<tam; ++i)
            if ((memoria.get(i).getProc() == null) && memoria.get(i).getTam()>= p.getTamanio())
                return i;
        return -1;
    }
    
    public static void particionar(int particion, Proceso p){
        Particion par = memoria.get(particion);
        Particion nueva = new Particion(par.getInicio(), p.getTamanio(), p);
        p.setParticion(nueva);
        Particion resto = new Particion(nueva.getFin(), par.getTam()- nueva.getTam(), null);
        memoria.add(particion,nueva);
        memoria.add(particion+1,resto);
        memoria.remove(particion+2);
        nueva.getProc().start();
    }
    
    public static void mostrar()
    {
        //System.out.println(memoria.size());
        for(Particion par: memoria)
        {
            par.mostrar();
        }
    }
    
   public static void borrar(){
       for (int i: borrar)
       {
           //System.out.println("borrar prooceso: "+ i);
           procesos.remove(i);
       }
       borrar.clear();
   }
}