import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Rectangle;
import javax.swing.JPanel;

public class Memoria extends JPanel{
    private static int height = 650;
    private static int x_lateral = 250;
    private Color colors[] = {Color.RED, Color.DARK_GRAY, Color.MAGENTA};
    private double unidad; 
    Memoria(int tam){
        this.setBackground(Color.BLACK);
        this.setVisible(true);
        this.setBounds(300, 10, x_lateral, height);
        unidad =(double)height/(double)tam;
        //System.out.println(unidad);
    }
    
    public void paint(Graphics g){
        //asignar();
        g.setColor(Color.CYAN);
        g.fillRect(10, 10, 200, height);
        
        g.setColor(Color.red);
        g.fillRect(10, 20, 200,(int)(unidad*25)-2);
        g.setFont(new Font("Serif", Font.PLAIN, 12));
        g.setColor(Color.BLACK);
        g.drawString("proceso 0 \\n 50 MB", 50, 50);
    }
    /*public void paint(Graphics g){
        g.setColor(Color.CYAN);
        g.fillRect(10, 10, 200, height);
        g.setColor(Color.red);
        g.fillRect(10, 20, 200,(int)(unidad*100)-2);
        g.setFont(new Font("Serif", Font.PLAIN, 12));
        g.setColor(Color.BLACK);
        g.drawString("proceso 0 \\n 50 MB", 50, 50);
    }*/
}
