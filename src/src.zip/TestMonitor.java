public class TestMonitor {
   
    public static void main(String args[]){
        Monitor mon = new Monitor();
    }
}
